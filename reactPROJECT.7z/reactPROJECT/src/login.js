import React, { Component } from 'react';


class Login extends Component {
  render() {
    return (
      <div className="login">
      <h1>Login Component</h1>

      </div>
    );
  }
}

export default Login;
