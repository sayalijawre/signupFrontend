import React, { Component } from 'react';
import { BrowserRouter as Router, Switch, Route} from 'react-router-dom';
import './App.css';
import Signup from './signup';
import Login from './login';
import LinkVerification from './linkVerification'

class App extends Component {
  render() {
    return (
      <Router>
        <div>
      

        <Switch>
            <Route exact path='/' component={Signup} />
            <Route exact path='/Login' component={Login} />
            <Route exact path='/LinkVerification/:userName/:verificationCode' component={LinkVerification} />
          </Switch>
        </div>
      </Router>
    );
  }
}

export default App;



